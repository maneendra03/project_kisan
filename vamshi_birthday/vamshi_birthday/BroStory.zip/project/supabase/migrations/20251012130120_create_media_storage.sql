/*
  # BroStory Media Storage Setup

  1. Storage Buckets
    - Create 'brostory-media' bucket for photos and videos
    - Public access enabled for viewing
    
  2. Tables
    - `media_items` - Stores metadata for all uploaded media
      - `id` (uuid, primary key)
      - `filename` (text)
      - `storage_path` (text)
      - `media_type` (text) - 'photo' or 'video'
      - `year` (integer) - Year from 2017-2025
      - `caption` (text) - Funny caption for the media
      - `order_index` (integer) - For custom ordering
      - `created_at` (timestamp)
    
    - `quiz_questions` - Store quiz questions and answers
      - `id` (uuid, primary key)
      - `question` (text)
      - `options` (jsonb) - Array of answer options
      - `correct_answer` (integer) - Index of correct answer
      - `order_index` (integer)
      - `created_at` (timestamp)
    
  3. Security
    - Enable RLS on all tables
    - Public read access for media_items and quiz_questions
    - No write access needed (admin uploads separately)
*/

-- Create storage bucket for media
INSERT INTO storage.buckets (id, name, public)
VALUES ('brostory-media', 'brostory-media', true)
ON CONFLICT (id) DO NOTHING;

-- Create media_items table
CREATE TABLE IF NOT EXISTS media_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  storage_path text NOT NULL,
  media_type text NOT NULL CHECK (media_type IN ('photo', 'video')),
  year integer NOT NULL CHECK (year >= 2017 AND year <= 2025),
  caption text DEFAULT '',
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE media_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view media items"
  ON media_items FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create quiz_questions table
CREATE TABLE IF NOT EXISTS quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  options jsonb NOT NULL,
  correct_answer integer NOT NULL,
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quiz_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view quiz questions"
  ON quiz_questions FOR SELECT
  TO anon, authenticated
  USING (true);

-- Storage policies for public access
CREATE POLICY "Public read access"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'brostory-media');

-- Insert sample quiz questions
INSERT INTO quiz_questions (question, options, correct_answer, order_index)
VALUES 
  ('What is Vamshi''s most used excuse?', '["I forgot", "Trust me bro", "One last time", "Technical issues"]', 1, 1),
  ('How many times has he said "one last game"?', '["Never", "Once a week", "Infinite times", "Only on weekends"]', 2, 2),
  ('What is Vamshi''s superpower?', '["Being on time", "Perfect memory", "Turning 5 minutes into 5 hours", "Cooking skills"]', 2, 3),
  ('Vamshi''s favorite activity?', '["Studying", "Going to gym", "Gaming till sunrise", "Morning jogs"]', 2, 4),
  ('How many times have you both almost got in trouble?', '["Never", "Once or twice", "Too many to count", "We always get caught"]', 2, 5),
  ('Vamshi''s go-to food order?', '["Salad", "Whatever is cheapest", "Always the same thing", "Random experiments"]', 2, 6),
  ('When does Vamshi reply to messages?', '["Immediately", "Within an hour", "3-5 business days", "Only when reminded"]', 2, 7),
  ('Vamshi''s morning routine?', '["5 AM workout", "Snooze alarm 10 times", "Meditation", "Healthy breakfast"]', 1, 8),
  ('Best way to annoy Vamshi?', '["Steal his food", "Beat him in games", "Wake him up early", "All of the above"]', 3, 9),
  ('Your friendship in one word?', '["Normal", "Boring", "Legendary Chaos", "Suspicious"]', 2, 10)
ON CONFLICT DO NOTHING;