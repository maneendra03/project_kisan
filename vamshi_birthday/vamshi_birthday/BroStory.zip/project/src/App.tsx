import { useState } from 'react';
import LandingPage from './components/LandingPage';
import Navigation from './components/Navigation';
import TimelineSection from './components/TimelineSection';
import MemeGallery from './components/MemeGallery';
import QuizSection from './components/QuizSection';
import ThenVsNow from './components/ThenVsNow';
import BroCodeSection from './components/BroCodeSection';
import BirthdayFinale from './components/BirthdayFinale';

function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [currentSection, setCurrentSection] = useState('timeline');

  const handleEnter = () => {
    setShowLanding(false);
  };

  const handleReplay = () => {
    setShowLanding(true);
    setCurrentSection('timeline');
  };

  const handleNavigate = (section: string) => {
    setCurrentSection(section);
  };

  if (showLanding) {
    return <LandingPage onEnter={handleEnter} />;
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <Navigation onNavigate={handleNavigate} currentSection={currentSection} />

      <div className="pt-20">
        {currentSection === 'timeline' && <TimelineSection />}
        {currentSection === 'gallery' && <MemeGallery />}
        {currentSection === 'quiz' && <QuizSection />}
        {currentSection === 'then-now' && <ThenVsNow />}
        {currentSection === 'bro-code' && <BroCodeSection />}
        {currentSection === 'finale' && <BirthdayFinale onReplay={handleReplay} />}
      </div>
    </div>
  );
}

export default App;
