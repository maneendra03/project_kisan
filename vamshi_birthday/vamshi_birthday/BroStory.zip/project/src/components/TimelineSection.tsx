import { useEffect, useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase, MediaItem } from '../lib/supabase';

interface YearData {
  year: number;
  title: string;
  media: MediaItem[];
}

export default function TimelineSection() {
  const [years, setYears] = useState<YearData[]>([]);
  const [currentYearIndex, setCurrentYearIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMediaByYear();
  }, []);

  const loadMediaByYear = async () => {
    const { data, error } = await supabase
      .from('media_items')
      .select('*')
      .order('year', { ascending: true })
      .order('order_index', { ascending: true });

    if (error) {
      console.error('Error loading media:', error);
      setLoading(false);
      return;
    }

    const yearTitles: Record<number, string> = {
      2017: 'The Dumb Duo Assembles',
      2018: 'Learning to be Idiots Together',
      2019: 'Peak Chaos Era',
      2020: 'Survived the Impossible',
      2021: 'Still Going Strong',
      2022: 'New Level of Madness',
      2023: 'Eight Years and Counting',
      2024: 'The Legend Continues',
      2025: 'Current Status: Still Dumb'
    };

    const groupedByYear: Record<number, MediaItem[]> = {};
    data?.forEach(item => {
      if (!groupedByYear[item.year]) {
        groupedByYear[item.year] = [];
      }
      groupedByYear[item.year].push(item);
    });

    const yearsData: YearData[] = Object.entries(groupedByYear).map(([year, media]) => ({
      year: parseInt(year),
      title: yearTitles[parseInt(year)] || `Year ${year}`,
      media
    }));

    setYears(yearsData);
    setLoading(false);
  };

  const getMediaUrl = (path: string) => {
    const { data } = supabase.storage.from('brostory-media').getPublicUrl(path);
    return data.publicUrl;
  };

  const nextYear = () => {
    setCurrentYearIndex((prev) => (prev + 1) % years.length);
  };

  const prevYear = () => {
    setCurrentYearIndex((prev) => (prev - 1 + years.length) % years.length);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading memories...</div>
      </div>
    );
  }

  const currentYear = years[currentYearIndex];

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calendar className="w-10 h-10 text-blue-400" />
            <h2 className="text-5xl md:text-6xl font-black text-white">Timeline of Chaos</h2>
          </div>
          <p className="text-xl text-slate-300">2017 → 2025: Every Chapter of Our Nonsense</p>
        </div>

        {years.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">
              No memories uploaded yet. Upload your 100+ photos and videos to bring this timeline to life!
            </p>
            <p className="text-slate-500 mt-4 text-sm">
              Tip: Upload media through Supabase Storage bucket 'brostory-media' with year metadata
            </p>
          </div>
        ) : (
          <div className="relative">
            <div className="flex items-center justify-between mb-8">
              <button
                onClick={prevYear}
                className="p-4 bg-slate-800 hover:bg-slate-700 rounded-full transition-colors"
                aria-label="Previous year"
              >
                <ChevronLeft className="w-8 h-8 text-white" />
              </button>

              <div className="text-center">
                <h3 className="text-6xl font-black text-transparent bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text mb-2">
                  {currentYear?.year}
                </h3>
                <p className="text-2xl text-white font-bold">{currentYear?.title}</p>
              </div>

              <button
                onClick={nextYear}
                className="p-4 bg-slate-800 hover:bg-slate-700 rounded-full transition-colors"
                aria-label="Next year"
              >
                <ChevronRight className="w-8 h-8 text-white" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {currentYear?.media.map((item) => (
                <div
                  key={item.id}
                  className="group relative bg-slate-800 rounded-2xl overflow-hidden hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-blue-500/20"
                >
                  {item.media_type === 'photo' ? (
                    <img
                      src={getMediaUrl(item.storage_path)}
                      alt={item.caption || `Memory from ${item.year}`}
                      className="w-full h-80 object-cover"
                    />
                  ) : (
                    <video
                      src={getMediaUrl(item.storage_path)}
                      controls
                      className="w-full h-80 object-cover"
                    />
                  )}

                  {item.caption && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-6 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                      <p className="text-white text-lg font-medium">{item.caption}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-center gap-2">
              {years.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentYearIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentYearIndex
                      ? 'bg-blue-400 w-8'
                      : 'bg-slate-600 hover:bg-slate-500'
                  }`}
                  aria-label={`Go to year ${years[index].year}`}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
