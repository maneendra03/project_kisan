import { useEffect, useState } from 'react';
import { ImageIcon } from 'lucide-react';
import { supabase, MediaItem } from '../lib/supabase';

export default function MemeGallery() {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);

  useEffect(() => {
    loadAllMedia();
  }, []);

  const loadAllMedia = async () => {
    const { data, error } = await supabase
      .from('media_items')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading media:', error);
      setLoading(false);
      return;
    }

    setMedia(data || []);
    setLoading(false);
  };

  const getMediaUrl = (path: string) => {
    const { data } = supabase.storage.from('brostory-media').getPublicUrl(path);
    return data.publicUrl;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading gallery...</div>
      </div>
    );
  }

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-800 via-slate-900 to-slate-800 py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ImageIcon className="w-10 h-10 text-cyan-400" />
            <h2 className="text-5xl md:text-6xl font-black text-white">Certified Bro Moments</h2>
          </div>
          <p className="text-xl text-slate-300">The Hall of Fame (and Shame)</p>
        </div>

        {media.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">
              Gallery is waiting for your 100+ photos and videos!
            </p>
            <p className="text-slate-500 mt-4 text-sm">
              Upload media to Supabase Storage to populate this gallery
            </p>
          </div>
        ) : (
          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
            {media.map((item) => (
              <div
                key={item.id}
                className="group relative break-inside-avoid bg-slate-800 rounded-2xl overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/20"
                onClick={() => setSelectedMedia(item)}
              >
                {item.media_type === 'photo' ? (
                  <img
                    src={getMediaUrl(item.storage_path)}
                    alt={item.caption || 'Bro moment'}
                    className="w-full h-auto object-cover"
                  />
                ) : (
                  <div className="relative">
                    <video
                      src={getMediaUrl(item.storage_path)}
                      className="w-full h-auto object-cover"
                      muted
                      loop
                      playsInline
                      onMouseEnter={(e) => e.currentTarget.play()}
                      onMouseLeave={(e) => e.currentTarget.pause()}
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition-colors">
                      <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center">
                        <div className="w-0 h-0 border-l-8 border-l-slate-900 border-y-4 border-y-transparent ml-1"></div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-6 w-full">
                    <p className="text-white text-lg font-medium">
                      {item.caption || 'Another legendary moment'}
                    </p>
                    <p className="text-cyan-400 text-sm mt-2">{item.year}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedMedia && (
        <div
          className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-6"
          onClick={() => setSelectedMedia(null)}
        >
          <div className="relative max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setSelectedMedia(null)}
              className="absolute -top-12 right-0 text-white text-4xl hover:text-cyan-400 transition-colors"
            >
              ×
            </button>

            {selectedMedia.media_type === 'photo' ? (
              <img
                src={getMediaUrl(selectedMedia.storage_path)}
                alt={selectedMedia.caption}
                className="w-full h-auto max-h-[80vh] object-contain rounded-2xl"
              />
            ) : (
              <video
                src={getMediaUrl(selectedMedia.storage_path)}
                controls
                autoPlay
                className="w-full h-auto max-h-[80vh] object-contain rounded-2xl"
              />
            )}

            {selectedMedia.caption && (
              <div className="mt-6 text-center">
                <p className="text-white text-2xl font-medium">{selectedMedia.caption}</p>
                <p className="text-cyan-400 text-lg mt-2">{selectedMedia.year}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
