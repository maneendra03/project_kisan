import { useEffect, useState } from 'react';
import { Cake, PartyPopper, Beer, RotateCcw } from 'lucide-react';

interface BirthdayFinaleProps {
  onReplay: () => void;
}

export default function BirthdayFinale({ onReplay }: BirthdayFinaleProps) {
  const [showConfetti, setShowConfetti] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowConfetti(true);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const handleBeerClick = () => {
    setIsPlaying(true);
    setTimeout(() => setIsPlaying(false), 1000);
  };

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 py-20 px-6 flex items-center justify-center relative overflow-hidden">
      {showConfetti && (
        <>
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(50)].map((_, i) => (
              <div
                key={i}
                className="confetti absolute w-3 h-3 rounded-full animate-confetti"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-${Math.random() * 20}%`,
                  backgroundColor: ['#3b82f6', '#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b'][
                    Math.floor(Math.random() * 5)
                  ],
                  animationDelay: `${Math.random() * 3}s`,
                  animationDuration: `${Math.random() * 3 + 2}s`
                }}
              />
            ))}
          </div>

          <div className="firework absolute top-20 left-20"></div>
          <div className="firework absolute top-32 right-32"></div>
          <div className="firework absolute bottom-40 left-40"></div>
          <div className="firework absolute bottom-20 right-20"></div>
        </>
      )}

      <div className="relative z-10 text-center max-w-4xl">
        <div className="mb-12 inline-block animate-bounce">
          <Cake className="w-24 h-24 text-pink-400" />
        </div>

        <h1 className="text-6xl md:text-8xl font-black text-white mb-6 leading-tight">
          <span className="block">Happy Birthday</span>
          <span className="block bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mt-4">
            Vamshi!
          </span>
        </h1>

        <div className="mb-12 space-y-4">
          <p className="text-2xl md:text-3xl text-white font-bold">
            8 Years of Chaos
          </p>
          <p className="text-2xl md:text-3xl text-white font-bold">
            Countless Memories
          </p>
          <p className="text-2xl md:text-3xl text-white font-bold">
            Infinite Brotherhood
          </p>
        </div>

        <div className="bg-slate-800/80 backdrop-blur rounded-3xl p-12 mb-12 border-2 border-purple-500/30">
          <PartyPopper className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
          <p className="text-xl md:text-2xl text-slate-200 leading-relaxed max-w-2xl mx-auto">
            From school days to now, we've survived everything together—bad decisions, worse haircuts,
            and countless "what were we thinking?" moments. Here's to many more years of legendary chaos!
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-6">
          <button
            onClick={onReplay}
            className="group px-10 py-5 bg-gradient-to-r from-blue-500 to-cyan-500 text-white text-xl font-bold rounded-full hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-blue-500/50 inline-flex items-center gap-3"
          >
            <RotateCcw className="w-6 h-6 group-hover:rotate-180 transition-transform duration-500" />
            Replay the Madness
          </button>

          <button
            onClick={handleBeerClick}
            className={`group px-10 py-5 bg-gradient-to-r from-orange-500 to-yellow-500 text-white text-xl font-bold rounded-full hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-orange-500/50 inline-flex items-center gap-3 ${
              isPlaying ? 'animate-bounce' : ''
            }`}
          >
            <Beer className={`w-6 h-6 ${isPlaying ? 'animate-spin' : ''}`} />
            Send Virtual Beer
          </button>
        </div>

        {isPlaying && (
          <div className="mt-8 text-4xl animate-fadeIn">🍺🎉🥳🎊✨</div>
        )}

        <div className="mt-16 inline-block">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-1 rounded-2xl">
            <div className="bg-slate-900 px-8 py-4 rounded-2xl">
              <p className="text-white text-lg">
                Made with <span className="text-red-400 animate-pulse">❤️</span> and{' '}
                <span className="text-yellow-400">way too many memories</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes confetti {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }

        .animate-confetti {
          animation: confetti linear infinite;
        }

        .firework {
          width: 4px;
          height: 4px;
          background: white;
          border-radius: 50%;
          animation: firework-animation 2s ease-out infinite;
        }

        @keyframes firework-animation {
          0% {
            transform: translate(0, 0);
            opacity: 1;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: translate(var(--tx, 0), var(--ty, 0));
            opacity: 0;
          }
        }

        .firework::before,
        .firework::after {
          content: '';
          position: absolute;
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: white;
        }

        .firework::before {
          animation: firework-particle 2s ease-out infinite;
          --tx: 100px;
          --ty: -100px;
        }

        .firework::after {
          animation: firework-particle 2s ease-out infinite;
          --tx: -100px;
          --ty: -100px;
        }

        @keyframes firework-particle {
          0% {
            transform: translate(0, 0);
            opacity: 1;
          }
          100% {
            transform: translate(var(--tx), var(--ty));
            opacity: 0;
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.5);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </section>
  );
}
