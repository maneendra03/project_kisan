import { Shield, Flame } from 'lucide-react';

export default function BroCodeSection() {
  const broCodeRules = [
    "Never let Vamshi order food alone",
    "What happens in 2020 stays in 2020",
    "If one fails, both fail gloriously",
    "Always have each other's back (except in games)",
    "No screenshots of embarrassing chats",
    "Late night bad decisions are mandatory",
    "Pizza is always the answer",
    "Bros before... actually, just bros"
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <Shield className="w-12 h-12 text-blue-400" />
              <h2 className="text-4xl md:text-5xl font-black text-white">The Official Bro Code</h2>
            </div>

            <div className="space-y-4">
              {broCodeRules.map((rule, index) => (
                <div
                  key={index}
                  className="bg-slate-800 p-6 rounded-2xl hover:bg-slate-700 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-blue-500/20 group"
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center font-bold text-white">
                      {index + 1}
                    </div>
                    <p className="text-xl text-white font-medium pt-1 group-hover:text-blue-400 transition-colors">
                      {rule}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-8">
              <Flame className="w-12 h-12 text-orange-400" />
              <h2 className="text-4xl md:text-5xl font-black text-white">Roast Zone</h2>
            </div>

            <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border-2 border-orange-500/50 rounded-3xl p-8 hover:scale-105 transition-all duration-300">
              <div className="space-y-6 text-white">
                <p className="text-2xl font-bold leading-relaxed">
                  Happy Birthday, Vamshi!
                </p>

                <p className="text-lg leading-relaxed">
                  Eight years of watching you say "just 5 more minutes" that turn into 5 hours.
                  Eight years of "I'll be there in 10" texts from someone who hasn't even left home yet.
                </p>

                <p className="text-lg leading-relaxed">
                  You've perfected the art of being confidently wrong, impressively lazy, and somehow still
                  getting away with everything. Your superpower isn't strength or speed—it's convincing
                  people you're about to change while staying exactly the same.
                </p>

                <p className="text-lg leading-relaxed">
                  But honestly? I wouldn't want it any other way. You're the chaos to my sanity, the
                  "bad idea" to my "let's do it anyway." Here's to 8 more years of questionable decisions
                  and legendary memories.
                </p>

                <div className="pt-4 border-t border-orange-500/30">
                  <p className="text-xl font-bold text-orange-400">
                    You're stuck with me, bro. Deal with it.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 bg-slate-800 rounded-2xl p-6 text-center">
              <p className="text-slate-400 text-sm mb-2">Friendship Status:</p>
              <div className="flex items-center justify-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <p className="text-2xl font-black text-transparent bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text">
                  UNBREAKABLE
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-block bg-slate-800 px-8 py-4 rounded-full">
            <p className="text-white font-medium">
              <span className="text-blue-400 font-bold">8 Years</span> of Chaos,{' '}
              <span className="text-cyan-400 font-bold">Countless</span> Memories,{' '}
              <span className="text-purple-400 font-bold">Infinite</span> Brotherhood
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
