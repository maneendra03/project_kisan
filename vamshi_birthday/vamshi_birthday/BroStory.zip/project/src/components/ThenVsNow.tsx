import { ArrowRight } from 'lucide-react';

interface Comparison {
  then: {
    image: string;
    caption: string;
  };
  now: {
    image: string;
    caption: string;
  };
}

export default function ThenVsNow() {
  const comparisons: Comparison[] = [
    {
      then: {
        image: 'https://images.pexels.com/photos/1462630/pexels-photo-1462630.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Used to borrow pens'
      },
      now: {
        image: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: "Still doesn't bring one"
      }
    },
    {
      then: {
        image: 'https://images.pexels.com/photos/1438072/pexels-photo-1438072.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Dreamed of passing exams'
      },
      now: {
        image: 'https://images.pexels.com/photos/5212320/pexels-photo-5212320.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Still dreaming'
      }
    },
    {
      then: {
        image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Thought we were cool'
      },
      now: {
        image: 'https://images.pexels.com/photos/5212662/pexels-photo-5212662.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Now we know better'
      }
    },
    {
      then: {
        image: 'https://images.pexels.com/photos/1516440/pexels-photo-1516440.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Full of energy'
      },
      now: {
        image: 'https://images.pexels.com/photos/6957562/pexels-photo-6957562.jpeg?auto=compress&cs=tinysrgb&w=800',
        caption: 'Permanently tired'
      }
    }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-800 via-slate-900 to-slate-800 py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black text-white mb-4">Then vs Now</h2>
          <p className="text-xl text-slate-300">The Evolution of Two Idiots</p>
        </div>

        <div className="space-y-12">
          {comparisons.map((comparison, index) => (
            <div
              key={index}
              className="bg-slate-800/50 backdrop-blur rounded-3xl overflow-hidden hover:shadow-2xl hover:shadow-blue-500/10 transition-all duration-300"
            >
              <div className="grid md:grid-cols-[1fr,auto,1fr] gap-0 md:gap-8 items-center p-6 md:p-8">
                <div className="space-y-4">
                  <div className="relative group overflow-hidden rounded-2xl">
                    <img
                      src={comparison.then.image}
                      alt={comparison.then.caption}
                      className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4 bg-blue-500 text-white px-4 py-2 rounded-full font-bold">
                      THEN
                    </div>
                  </div>
                  <p className="text-xl text-white font-medium text-center">
                    {comparison.then.caption}
                  </p>
                </div>

                <div className="flex justify-center my-6 md:my-0">
                  <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-full">
                    <ArrowRight className="w-8 h-8 text-white transform md:rotate-0 rotate-90" />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="relative group overflow-hidden rounded-2xl">
                    <img
                      src={comparison.now.image}
                      alt={comparison.now.caption}
                      className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4 bg-cyan-500 text-white px-4 py-2 rounded-full font-bold">
                      NOW
                    </div>
                  </div>
                  <p className="text-xl text-white font-medium text-center">
                    {comparison.now.caption}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="inline-block bg-gradient-to-r from-blue-500 to-cyan-500 p-1 rounded-3xl">
            <div className="bg-slate-900 px-12 py-8 rounded-3xl">
              <p className="text-3xl md:text-4xl font-black text-white">
                Still idiots, just older
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-slate-400 text-sm">
            Tip: Replace these stock photos with your actual Then vs Now photos by uploading to Supabase Storage!
          </p>
        </div>
      </div>
    </section>
  );
}
