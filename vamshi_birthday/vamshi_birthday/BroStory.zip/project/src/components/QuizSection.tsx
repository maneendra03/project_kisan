import { useEffect, useState } from 'react';
import { Brain, CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import { supabase, QuizQuestion } from '../lib/supabase';

export default function QuizSection() {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    const { data, error } = await supabase
      .from('quiz_questions')
      .select('*')
      .order('order_index', { ascending: true });

    if (error) {
      console.error('Error loading questions:', error);
      setLoading(false);
      return;
    }

    setQuestions(data || []);
    setLoading(false);
  };

  const handleAnswer = (index: number) => {
    if (answered) return;

    setSelectedAnswer(index);
    setAnswered(true);

    if (index === questions[currentQuestion].correct_answer) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setAnswered(false);
      } else {
        setShowResult(true);
      }
    }, 1500);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
    setAnswered(false);
  };

  const getResultMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage === 100) {
      return {
        title: 'LEGENDARY BRO STATUS',
        message: "You've survived the full Vamshi experience. You know him better than he knows himself!",
        emoji: '🏆',
        color: 'from-yellow-400 to-orange-400'
      };
    } else if (percentage >= 70) {
      return {
        title: 'Certified Bro',
        message: "You know Vamshi well! You've been through the chaos together.",
        emoji: '😎',
        color: 'from-blue-400 to-cyan-400'
      };
    } else if (percentage >= 40) {
      return {
        title: 'Casual Friend',
        message: "You know some stuff, but there's more chaos to discover!",
        emoji: '🤔',
        color: 'from-slate-400 to-slate-500'
      };
    } else {
      return {
        title: 'Fake Friend Alert',
        message: 'Do you even know Vamshi? Time to make more memories!',
        emoji: '🚨',
        color: 'from-red-400 to-pink-400'
      };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading quiz...</div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-slate-400 text-xl">Quiz questions not available</div>
      </div>
    );
  }

  const result = getResultMessage();

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-20 px-6 flex items-center">
      <div className="max-w-4xl mx-auto w-full">
        {!showResult ? (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Brain className="w-10 h-10 text-purple-400" />
                <h2 className="text-5xl md:text-6xl font-black text-white">
                  How Well Do You Know Vamshi?
                </h2>
              </div>
              <div className="flex justify-center gap-2 mt-6">
                {questions.map((_, index) => (
                  <div
                    key={index}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      index === currentQuestion
                        ? 'w-12 bg-purple-400'
                        : index < currentQuestion
                        ? 'w-8 bg-green-400'
                        : 'w-8 bg-slate-700'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="bg-slate-800 rounded-3xl p-8 md:p-12 shadow-2xl">
              <div className="mb-4 text-slate-400 text-sm font-medium">
                Question {currentQuestion + 1} of {questions.length}
              </div>

              <h3 className="text-3xl md:text-4xl font-bold text-white mb-8">
                {questions[currentQuestion].question}
              </h3>

              <div className="space-y-4">
                {questions[currentQuestion].options.map((option, index) => {
                  const isSelected = selectedAnswer === index;
                  const isCorrect = index === questions[currentQuestion].correct_answer;
                  const showAnswer = answered;

                  let buttonClass = 'bg-slate-700 hover:bg-slate-600';

                  if (showAnswer) {
                    if (isCorrect) {
                      buttonClass = 'bg-green-500/20 border-2 border-green-400';
                    } else if (isSelected && !isCorrect) {
                      buttonClass = 'bg-red-500/20 border-2 border-red-400';
                    } else {
                      buttonClass = 'bg-slate-700';
                    }
                  } else if (isSelected) {
                    buttonClass = 'bg-purple-600 ring-2 ring-purple-400';
                  }

                  return (
                    <button
                      key={index}
                      onClick={() => handleAnswer(index)}
                      disabled={answered}
                      className={`w-full text-left p-6 rounded-2xl transition-all duration-300 ${buttonClass} ${
                        answered ? 'cursor-not-allowed' : 'hover:scale-102 cursor-pointer'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-white text-xl font-medium">{option}</span>
                        {showAnswer && isCorrect && (
                          <CheckCircle className="w-6 h-6 text-green-400" />
                        )}
                        {showAnswer && isSelected && !isCorrect && (
                          <XCircle className="w-6 h-6 text-red-400" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="text-center">
              <p className="text-slate-400">
                Score: <span className="text-white font-bold text-xl">{score}</span> /{' '}
                {questions.length}
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-8">
            <div className="text-8xl mb-8 animate-bounce">{result.emoji}</div>

            <h2
              className={`text-5xl md:text-6xl font-black bg-gradient-to-r ${result.color} bg-clip-text text-transparent mb-4`}
            >
              {result.title}
            </h2>

            <div className="bg-slate-800 rounded-3xl p-12 shadow-2xl">
              <div className="text-6xl font-black text-white mb-4">
                {score} / {questions.length}
              </div>
              <div className="text-2xl text-slate-300 mb-6">
                {Math.round((score / questions.length) * 100)}% Correct
              </div>
              <p className="text-xl text-slate-400 max-w-2xl mx-auto">{result.message}</p>
            </div>

            <button
              onClick={resetQuiz}
              className="group px-10 py-5 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xl font-bold rounded-full hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/50 inline-flex items-center gap-3"
            >
              <RotateCcw className="w-6 h-6 group-hover:rotate-180 transition-transform duration-500" />
              Take Quiz Again
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
